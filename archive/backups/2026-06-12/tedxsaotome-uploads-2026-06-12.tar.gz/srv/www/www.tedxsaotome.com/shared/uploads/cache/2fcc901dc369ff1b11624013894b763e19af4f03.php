<!doctype html>
<html <?php echo e(get_language_attributes()); ?>>
  <?php echo $__env->make('partials.header.head', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <body <?php body_class() ?>>
    <?php do_action('get_header') ?>
    <div class="ui fluid container" role="document">
      <main class="main">
        <?php echo $__env->yieldContent('content'); ?>
      </main>
    </div>
    <?php do_action('get_footer') ?>
    <?php wp_footer() ?>
  </body>
</html>
