<div class="ui section footer" id="footer">
	<div class="ui basic segment">
		<div class="ui container">

			<div class="ui three column stackable doubling grid">

				<div class="column">
					<img class="ui small image" alt="Logo" src="<?= App\asset_path('images/tedxsaotome-logo.svg'); ?>">
					<div class="ui grey text mt1">This independent TEDx event is operated under license from TED.</div>
					<!--<div class="ui red header">Inscrever</div>-->
				</div>
				<div class="column">
					<div class="ui red header">Contate-Nos</div>
					<div class="ui grey text">info@tedxsaotome.com</div>
					<!--<div class="ui grey text">+239 902 231 16</div>-->
					<div class="ui red header">Navegação</div>
					<div class="ui black mini inverted menu">
						<a class="fitted item" href="#about">Sobre TEDx</a>
						<a class="item" href="#speakers">Oradores</a>
						<!--<a class="fitted item" href="#team">Equipe</a>
						<a class="item" href="#sponsors">Parceiros</a>-->
					</div>
				</div>
				<div class="column">
					<div class="ui red header">Social</div>
					<div class="ui grey text">Siga-nos nas mídias sociais para receber atualizações sobre o evento.</div>
					<div class="ui buttons pt1">
						<a href="https://www.facebook.com/tedxsaotome" target="_blank" class="ui facebook icon button">
							<i class="facebook icon"></i>
						</a>
						<a href="https://www.instagram.com/tedxsaotome/" target="_blank" class="ui instagram icon button">
							<i class="instagram icon"></i>
						</a>
						<a href="https://twitter.com/tedxsaotome" target="_blank" class="ui twitter icon button">
							<i class="twitter icon"></i>
						</a>
						<a href="https://www.youtube.com/results?search_query=tedxsaotome" target="_blank" class="ui youtube icon button">
							<i class="youtube icon"></i>
						</a>
					</div>
				</div>

			</div>
		</div>
	</div>
</div>
